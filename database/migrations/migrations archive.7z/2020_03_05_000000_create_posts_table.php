<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostsTable extends Migration
{
	
	protected $primaryKey = 'posts_id';
	
	public function up()
	{
		Schema::create('posts_table', function (Blueprint $table) {
			$table->Increments('posts_id');
			$table->bigInteger('user_id');
			$table->string('title');
			$table->string('comment');
			$table->bigInteger('priority');
			$table->string('author');
			$table->string('author_picture');
			$table->timestamps();
		});
	}
	public function down()
	{
		Schema::dropIfExists('posts_table');
	}
}
?>