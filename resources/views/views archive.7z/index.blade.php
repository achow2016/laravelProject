@extends('welcome')

@section('content')
        <div class="col-md">
            <a href="/login" class="btn btn-light btn-lg">
                <i class="fab fa-facebook"></i>
                Login with Facebook!
            </a>
        </div>
@endsection
