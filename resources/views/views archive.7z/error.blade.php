@extends('welcome')

@section('content')
        <div class="col-md">
            <h2>{{$message}}</h2>
        </div>
@endsection
